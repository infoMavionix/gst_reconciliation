import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";
import { AuthProvider } from "./auth/AuthContext";
import ProtectedRoute from "./components/ProtectedRoute";
import AppLayout from "./components/AppLayout";
import AuthPage from "./pages/AuthPage";
import Dashboard from "./pages/Dashboard";
import BillingPage from "./pages/BillingPage";
import PlaceholderPage from "./pages/PlaceholderPage";
import UploadsPage from "./pages/UploadsPage";
import ReconciliationPage from "./pages/ReconciliationPage";

export default function App() {
  return <AuthProvider><BrowserRouter><Routes>
    <Route path="/login" element={<AuthPage mode="login" />} />
    <Route path="/register" element={<AuthPage mode="register" />} />
    <Route element={<ProtectedRoute />}>
      <Route element={<AppLayout />}>
        <Route path="/" element={<Dashboard />} />
        <Route path="/uploads" element={<UploadsPage />} />
        <Route path="/reconciliation" element={<ReconciliationPage />} />
        <Route path="/vendors" element={<PlaceholderPage title="Vendors" description="Supplier GSTIN directory, vendor contacts and discrepancy tracking will be implemented in Phase 2." />} />
        <Route path="/reports" element={<PlaceholderPage title="Reports" description="Downloadable reconciliation summaries and vendor discrepancy reports will be implemented in Phase 4." />} />
        <Route path="/settings" element={<PlaceholderPage title="Settings" description="Organization profile, GST details, team members and security settings will be expanded in upcoming phases." />} />
        <Route path="/billing" element={<BillingPage />} />
      </Route>
    </Route>
    <Route path="*" element={<Navigate to="/" replace />} />
  </Routes></BrowserRouter></AuthProvider>;
}
